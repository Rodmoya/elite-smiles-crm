<?php
declare(strict_types=1);

return [
    'premium_trust' => [
        'label' => 'Premium Trust',
        'question_set' => 'veneers-premium-trust.php',
    ],
    'financing' => [
        'label' => 'Financing',
        'question_set' => 'veneers-financing.php',
    ],
    'transformation' => [
        'label' => 'Transformation',
        'question_set' => 'veneers-transformation.php',
    ],
    'education_comparison' => [
        'label' => 'Education Comparison',
        'question_set' => 'veneers-education-comparison.php',
    ],
];
