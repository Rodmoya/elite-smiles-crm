<?php
declare(strict_types=1);

return [
    [
        'field' => 'q_main_concern',
        'title' => 'What are you comparing or trying to understand?',
        'text' => 'Choose the topic you care about most right now.',
        'options' => [
            'Cost and value',
            'Natural-looking results',
            'How veneers compare to other options',
            'Whether veneers are right for me',
        ],
    ],
    [
        'field' => 'q_goal',
        'title' => 'What is your main veneers goal?',
        'text' => 'Choose the option that best matches what you want.',
        'options' => [
            'Improve the overall look of my smile',
            'Whiten and enhance my front teeth',
            'Fix chips, wear, or uneven teeth',
            'Feel more confident smiling',
        ],
    ],
    [
        'field' => 'q_timeline',
        'title' => 'How soon are you hoping to get started?',
        'text' => 'This helps us understand your timeline.',
        'options' => [
            'As soon as possible',
            'Within the next 1 to 3 months',
            'Within the next 6 months',
            'Just researching for now',
        ],
    ],
];
