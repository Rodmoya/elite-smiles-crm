<?php
declare(strict_types=1);

/**
 * Shared quiz modal placeholder.
 */
?>
