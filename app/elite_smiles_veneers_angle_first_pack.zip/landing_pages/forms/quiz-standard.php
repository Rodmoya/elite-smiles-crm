<?php
declare(strict_types=1);

/**
 * Placeholder form renderer.
 * Keep current live form in landing.php until the full split is finished.
 */
?>
<!-- quiz-standard renderer placeholder -->
