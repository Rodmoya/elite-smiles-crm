<?php
declare(strict_types=1);
?>
<!-- quiz modal partial placeholder -->
