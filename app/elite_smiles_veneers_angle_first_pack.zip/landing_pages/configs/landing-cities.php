<?php
declare(strict_types=1);

return [
    'draper' => ['label' => 'Draper', 'state' => 'Utah'],
    'lehi' => ['label' => 'Lehi', 'state' => 'Utah'],
    'south-jordan' => ['label' => 'South Jordan', 'state' => 'Utah'],
    'highland' => ['label' => 'Highland', 'state' => 'Utah'],
    'alpine' => ['label' => 'Alpine', 'state' => 'Utah'],
    'park-city' => ['label' => 'Park City', 'state' => 'Utah'],
    'farmington' => ['label' => 'Farmington', 'state' => 'Utah'],
    'cedar-hills' => ['label' => 'Cedar Hills', 'state' => 'Utah'],
];
