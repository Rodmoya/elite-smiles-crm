<?php
declare(strict_types=1);

return [
    [
        'field' => 'q_goal',
        'title' => 'What is your main veneers goal?',
        'text' => 'Choose the option that best matches what you want.',
        'options' => [
            'Improve the overall look of my smile',
            'Whiten and enhance my front teeth',
            'Fix chips, wear, or uneven teeth',
            'Feel more confident smiling',
        ],
    ],
    [
        'field' => 'financing_needed',
        'title' => 'Will you likely need financing?',
        'text' => 'This helps us prepare the best next step for you.',
        'options' => [
            'yes' => 'Yes',
            'no' => 'No',
            'unsure' => 'Unsure',
        ],
    ],
    [
        'field' => 'q_timeline',
        'title' => 'How soon are you hoping to get started?',
        'text' => 'This helps us understand your timeline.',
        'options' => [
            'As soon as possible',
            'Within the next 1 to 3 months',
            'Within the next 6 months',
            'Just researching for now',
        ],
    ],
];
