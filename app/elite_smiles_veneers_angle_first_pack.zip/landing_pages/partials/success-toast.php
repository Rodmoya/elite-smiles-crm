<?php
declare(strict_types=1);
?>
<!-- success toast partial placeholder -->
