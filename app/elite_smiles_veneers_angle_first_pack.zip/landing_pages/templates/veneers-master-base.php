<?php
declare(strict_types=1);
/**
 * Master veneers visual base.
 * Replace with the final proven veneers visual structure before wiring live loader.
 */
?>
<div class="min-h-screen">
    <header class="sticky top-0 z-40 border-b border-eliteBorder bg-white/95 backdrop-blur">
        <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
            <a href="<?= e(base_url()) ?>" class="shrink-0">
                <img src="<?= e($logoUrl ?? '') ?>" alt="Elite Smiles" class="h-auto w-[150px] max-w-full sm:w-[180px]">
            </a>
            <button type="button" data-open-quiz="1" class="cta-pill inline-flex items-center justify-center bg-eliteRose px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.08em] text-white transition hover:bg-eliteRoseDark sm:px-5 sm:text-sm">Offer</button>
        </div>
    </header>
    <main>
        <section class="bg-white">
            <div class="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
                <div class="rounded-[2rem] border border-eliteBorder bg-[#f5f2ee] p-10 text-center shadow-sm">
                    <h1 class="font-site-serif text-4xl text-eliteInk">Veneers Master Base</h1>
                    <p class="mt-4 text-eliteBody">This is the base visual scaffold for all veneers angles. Keep refining this first, then roll it to cities.</p>
                </div>
            </div>
        </section>
    </main>
</div>
