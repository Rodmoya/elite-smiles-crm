<?php
declare(strict_types=1);

/**
 * Shared standard head partial placeholder.
 */
?>
