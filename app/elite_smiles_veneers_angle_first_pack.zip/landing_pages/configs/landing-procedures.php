<?php
declare(strict_types=1);

return [
    'veneers' => [
        'label' => 'Veneers',
        'default_form_variant' => 'quiz-standard.php',
        'default_handler' => 'submit-quiz-standard.php',
    ],
];
