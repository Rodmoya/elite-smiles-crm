<?php
declare(strict_types=1);

return [
    'veneers-draper-v1' => [
        'template' => 'veneers-draper-premium-trust-v1.php',
        'active' => false,
        'procedure' => 'veneers',
        'angle' => 'premium_trust',
        'city' => 'draper',
        'question_set' => 'veneers-premium-trust.php',
        'form_variant' => 'quiz-standard.php',
        'handler' => 'submit-quiz-standard.php',
    ],
];
