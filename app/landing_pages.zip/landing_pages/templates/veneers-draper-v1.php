<?php
declare(strict_types=1);

/**
 * Elite Smiles
 * Template: veneers-draper-v1
 *
 * Full extracted live veneers template.
 * Assumes landing.php already prepared all variables.
 */
?>
<div class="min-h-screen">
    <header class="sticky top-0 z-40 border-b border-eliteBorder bg-white/95 backdrop-blur">
        <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
            <a href="<?= e(base_url()) ?>" class="shrink-0">
                <img
                    src="<?= e($logoUrl) ?>"
                    alt="Elite Smiles"
                    class="h-auto w-[150px] max-w-full sm:w-[180px]"
                >
            </a>

            <button
                type="button"
                data-open-quiz="1"
                data-track="cta_click"
                class="cta-pill inline-flex items-center justify-center bg-eliteRose px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.08em] text-white transition hover:bg-eliteRoseDark sm:px-5 sm:text-sm"
            >
                Offer
            </button>
        </div>
    </header>

    <main>
        <section class="bg-white" data-track-section="hero">
            <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 sm:py-10 lg:px-8 lg:py-12">
                <div class="overflow-hidden rounded-[2rem] bg-[#f5f2ee] ring-1 ring-eliteBorder shadow-sm">
                    <div class="relative min-h-[520px] sm:min-h-[620px] lg:min-h-[720px]">
                        <img
                            src="<?= e($heroImageUrl) ?>"
                            alt="<?= e($heroTitle) ?>"
                            class="absolute inset-0 block h-full w-full object-cover"
                            loading="eager"
                            fetchpriority="high"
                            decoding="async"
                        >
                        <div class="absolute inset-0 bg-gradient-to-r from-black/65 via-black/30 to-black/10"></div>
                        <div class="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-transparent"></div>

                        <div class="relative z-10 flex min-h-[520px] items-end sm:min-h-[620px] lg:min-h-[720px]">
                            <div class="w-full p-5 sm:p-8 lg:max-w-[760px] lg:p-12">
                                <div class="max-w-[640px] rounded-[1.75rem] bg-black/24 p-4 backdrop-blur-[3px] sm:p-6 lg:p-7">
                                    <?php if ($offerBadge !== ''): ?>
                                        <div class="inline-flex items-center rounded-full border border-white/25 bg-white/14 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-white sm:text-[11px]">
                                            <?= e($offerBadge) ?>
                                        </div>
                                    <?php endif; ?>

                                    <h1 class="mt-4 font-site-serif text-3xl font-semibold leading-[1.02] text-white sm:text-5xl lg:text-6xl">
                                        <?= e($heroTitle) ?>
                                    </h1>

                                    <p class="mt-4 max-w-2xl text-sm leading-6 text-white sm:text-lg sm:leading-8">
                                        <?= e($heroSubtitle) ?>
                                    </p>

                                    <div class="mt-6">
                                        <button
                                            type="button"
                                            data-open-quiz="1"
                                            data-track="cta_click"
                                            class="cta-pill inline-flex w-full max-w-[420px] items-center justify-center bg-eliteRose px-6 py-3.5 text-center text-sm font-semibold uppercase tracking-[0.06em] text-white shadow-lg transition hover:bg-eliteRoseDark sm:w-auto"
                                        >
                                            <?= e($primaryCtaText) ?>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="bg-eliteSageSoft" data-track-section="offer">
            <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                <div class="rounded-[2rem] bg-white px-5 py-6 ring-1 ring-eliteBorder shadow-sm sm:px-8 sm:py-8">
                    <div class="inline-flex items-center rounded-full bg-eliteStone px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-600 sm:text-[11px]">
                        <?= e($offerValueLabel) ?>
                    </div>

                    <h2 class="mt-4 font-site-serif text-3xl font-semibold leading-tight text-eliteInk sm:text-4xl">
                        <?= e($offerTitle) ?>
                    </h2>

                    <p class="mt-4 text-base leading-7 text-eliteBody sm:text-lg sm:leading-8">
                        <?= e($offerDescription) ?>
                    </p>

                    <div class="mt-5 grid gap-3 sm:grid-cols-2">
                        <?php foreach ($offerIncludedItems as $item): ?>
                            <div class="rounded-[1.25rem] bg-eliteStone px-4 py-4 text-sm leading-6 text-eliteBody ring-1 ring-eliteBorder">
                                <?= e($item) ?>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <p class="mt-5 text-sm leading-6 text-slate-700">
                        <?= e($offerFooterNote) ?>
                    </p>
                </div>
            </div>
        </section>

        <section class="bg-white" data-track-section="intro">
            <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                <div class="mx-auto max-w-3xl text-center">
                    <h2 class="font-site-serif text-3xl font-semibold leading-tight text-eliteInk sm:text-4xl">
                        <?= e($introTitle) ?>
                    </h2>

                    <?php if ($introText !== ''): ?>
                        <p class="mt-4 text-base leading-7 text-eliteBody sm:text-lg sm:leading-8">
                            <?= e($introText) ?>
                        </p>
                    <?php endif; ?>
                </div>

                <div class="mt-8 grid gap-4 md:grid-cols-3">
                    <div class="rounded-[1.5rem] bg-eliteStone px-5 py-5 text-sm leading-7 text-eliteBody ring-1 ring-eliteBorder">
                        <?= e($benefit1Title !== '' ? $benefit1Title . ' — ' . $benefit1Text : $benefit1Text) ?>
                    </div>

                    <div class="rounded-[1.5rem] bg-eliteStone px-5 py-5 text-sm leading-7 text-eliteBody ring-1 ring-eliteBorder">
                        <?= e($benefit2Title !== '' ? $benefit2Title . ' — ' . $benefit2Text : $benefit2Text) ?>
                    </div>

                    <div class="rounded-[1.5rem] bg-eliteStone px-5 py-5 text-sm leading-7 text-eliteBody ring-1 ring-eliteBorder">
                        <?= e($benefit3Title !== '' ? $benefit3Title . ' — ' . $benefit3Text : $benefit3Text) ?>
                    </div>
                </div>
            </div>
        </section>

        <?php if (!empty($galleryImages)): ?>
            <section class="bg-[#faf8f5] border-y border-eliteBorder" data-track-section="gallery">
                <div class="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                    <div class="mx-auto max-w-3xl text-center">
                        <div class="inline-flex items-center rounded-full bg-white px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-600 ring-1 ring-eliteBorder sm:text-[11px]">
                            Veneers Visual Direction
                        </div>
                        <h2 class="mt-4 font-site-serif text-3xl font-semibold leading-tight text-eliteInk sm:text-4xl">
                            Natural, Refined, and Designed to Feel Like You
                        </h2>
                        <p class="mt-4 text-base leading-7 text-eliteBody sm:text-lg sm:leading-8">
                            Veneers should look polished and elegant without feeling obvious. The right smile design is balanced, tasteful, and believable.
                        </p>
                    </div>

                    <?php if (count($galleryImages) >= 3): ?>
                        <div class="mt-8 grid gap-4 md:grid-cols-12">
                            <div class="md:col-span-7">
                                <div class="overflow-hidden rounded-[2rem] bg-white ring-1 ring-eliteBorder shadow-sm">
                                    <img
                                        src="<?= e($galleryImages[0]['url']) ?>"
                                        alt="<?= e($galleryImages[0]['alt']) ?>"
                                        class="h-[420px] w-full object-cover"
                                        loading="lazy"
                                        decoding="async"
                                    >
                                </div>
                            </div>

                            <div class="grid gap-4 md:col-span-5">
                                <?php foreach (array_slice($galleryImages, 1, 2) as $image): ?>
                                    <div class="overflow-hidden rounded-[2rem] bg-white ring-1 ring-eliteBorder shadow-sm">
                                        <img
                                            src="<?= e($image['url']) ?>"
                                            alt="<?= e($image['alt']) ?>"
                                            class="h-[202px] w-full object-cover"
                                            loading="lazy"
                                            decoding="async"
                                        >
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="mt-8">
                            <div class="overflow-hidden rounded-[2rem] bg-white ring-1 ring-eliteBorder shadow-sm">
                                <img
                                    src="<?= e($galleryImages[0]['url']) ?>"
                                    alt="<?= e($galleryImages[0]['alt']) ?>"
                                    class="h-[460px] w-full object-cover"
                                    loading="lazy"
                                    decoding="async"
                                >
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($beforeAfterImage !== ''): ?>
            <section class="bg-white border-b border-eliteBorder" data-track-section="before_after">
                <div class="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                    <div class="mx-auto max-w-3xl text-center">
                        <div class="inline-flex items-center rounded-full bg-eliteStone px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-600 ring-1 ring-eliteBorder sm:text-[11px]">
                            Real Transformation Direction
                        </div>
                        <h2 class="mt-4 font-site-serif text-3xl font-semibold leading-tight text-eliteInk sm:text-4xl">
                            A Beautiful Veneers Result Should Look Elevated, Not Fake
                        </h2>
                        <p class="mt-4 text-base leading-7 text-eliteBody sm:text-lg sm:leading-8">
                            The goal is not to erase your identity. The goal is to refine your smile in a way that feels naturally more polished, more balanced, and more confident.
                        </p>
                    </div>

                    <div class="mt-8 overflow-hidden rounded-[2rem] bg-white ring-1 ring-eliteBorder shadow-sm">
                        <img
                            src="<?= e($beforeAfterImage) ?>"
                            alt="<?= e($beforeAfterAlt) ?>"
                            class="w-full object-cover"
                            loading="lazy"
                            decoding="async"
                        >
                    </div>

                    <div class="mt-6 text-center">
                        <button
                            type="button"
                            data-open-quiz="1"
                            data-track="cta_click"
                            class="cta-pill inline-flex w-full max-w-[420px] items-center justify-center bg-eliteRose px-6 py-3 text-sm font-semibold uppercase tracking-[0.06em] text-white transition hover:bg-eliteRoseDark"
                        >
                            <?= e($primaryCtaText) ?>
                        </button>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <?php if (!empty($longFormSections)): ?>
            <section class="bg-white" data-track-section="longform">
                <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                    <div class="space-y-5">
                        <?php foreach ($longFormSections as $index => $section): ?>
                            <div class="rounded-[2rem] <?= $index % 2 === 0 ? 'bg-white' : 'bg-eliteStone' ?> px-6 py-7 ring-1 ring-eliteBorder shadow-sm sm:px-8 sm:py-9">
                                <?php if (!empty($section['eyebrow'])): ?>
                                    <div class="text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-500 sm:text-[11px]">
                                        <?= e((string) $section['eyebrow']) ?>
                                    </div>
                                <?php endif; ?>

                                <h2 class="mt-3 font-site-serif text-3xl font-semibold leading-tight text-eliteInk sm:text-4xl">
                                    <?= e((string) ($section['title'] ?? '')) ?>
                                </h2>

                                <p class="mt-4 text-base leading-7 text-eliteBody sm:text-lg sm:leading-8">
                                    <?= e((string) ($section['body'] ?? '')) ?>
                                </p>

                                <?php if ($procedureType === 'veneers' && ($index === 1 || $index === 3)): ?>
                                    <div class="mt-6">
                                        <button
                                            type="button"
                                            data-open-quiz="1"
                                            data-track="cta_click"
                                            class="cta-pill inline-flex w-full max-w-[420px] items-center justify-center bg-eliteRose px-6 py-3 text-sm font-semibold uppercase tracking-[0.06em] text-white transition hover:bg-eliteRoseDark sm:w-auto"
                                        >
                                            <?= e($primaryCtaText) ?>
                                        </button>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <section class="border-t border-eliteBorder bg-white" data-track-section="qualification">
            <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                <div class="rounded-[2rem] bg-eliteStone px-6 py-7 text-center ring-1 ring-eliteBorder sm:px-8 sm:py-9">
                    <h2 class="font-site-serif text-3xl font-semibold leading-tight text-eliteInk sm:text-4xl">
                        <?= e($qualificationTitle) ?>
                    </h2>

                    <p class="mt-4 text-base leading-7 text-eliteBody sm:text-lg sm:leading-8">
                        <?= e($qualificationText) ?>
                    </p>

                    <button
                        type="button"
                        data-open-quiz="1"
                        data-track="cta_click"
                        class="cta-pill mt-6 inline-flex w-full max-w-[420px] items-center justify-center bg-eliteRose px-6 py-3 text-sm font-semibold uppercase tracking-[0.06em] text-white transition hover:bg-eliteRoseDark"
                    >
                        <?= e($primaryCtaText) ?>
                    </button>
                </div>
            </div>
        </section>

        <?php if (!empty($faqItems)): ?>
            <section class="bg-[#faf8f5] border-t border-eliteBorder" data-track-section="faq">
                <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                    <div class="mx-auto max-w-3xl text-center">
                        <div class="inline-flex items-center rounded-full bg-white px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-slate-600 ring-1 ring-eliteBorder sm:text-[11px]">
                            Frequently Asked Questions
                        </div>
                        <h2 class="mt-4 font-site-serif text-3xl font-semibold leading-tight text-eliteInk sm:text-4xl">
                            Veneers Questions Patients Usually Ask First
                        </h2>
                    </div>

                    <div class="mt-8 space-y-4">
                        <?php foreach ($faqItems as $item): ?>
                            <div class="rounded-[1.5rem] bg-white px-6 py-6 ring-1 ring-eliteBorder shadow-sm">
                                <h3 class="text-base font-semibold text-eliteInk sm:text-lg">
                                    <?= e((string) ($item['question'] ?? '')) ?>
                                </h3>
                                <p class="mt-3 text-sm leading-7 text-eliteBody sm:text-base">
                                    <?= e((string) ($item['answer'] ?? '')) ?>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <section class="border-t border-eliteBorder bg-white" data-track-section="final_cta">
            <div class="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-12 lg:px-8">
                <div class="overflow-hidden rounded-[2rem] bg-[#1f1a17] px-6 py-8 text-center ring-1 ring-black/10 shadow-xl sm:px-10 sm:py-12">
                    <div class="inline-flex items-center rounded-full border border-white/15 bg-white/8 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-white/80 sm:text-[11px]">
                        Elite Smiles in Draper
                    </div>

                    <h2 class="mt-4 font-site-serif text-3xl font-semibold leading-tight text-white sm:text-5xl">
                        <?= e($finalCtaTitle) ?>
                    </h2>

                    <p class="mx-auto mt-4 max-w-3xl text-base leading-7 text-white/80 sm:text-lg sm:leading-8">
                        <?= e($finalCtaText) ?>
                    </p>

                    <button
                        type="button"
                        data-open-quiz="1"
                        data-track="cta_click"
                        class="cta-pill mt-7 inline-flex w-full max-w-[420px] items-center justify-center bg-eliteRose px-6 py-3.5 text-sm font-semibold uppercase tracking-[0.06em] text-white transition hover:bg-eliteRoseDark"
                    >
                        <?= e($primaryCtaText) ?>
                    </button>
                </div>
            </div>
        </section>
    </main>
</div>